﻿namespace QLBH
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Main));
            DevExpress.Utils.Animation.PushTransition pushTransition1 = new DevExpress.Utils.Animation.PushTransition();
            this.ribbonPage8 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage6 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_HoaDon = new DevExpress.XtraBars.BarButtonItem();
            this.btn_ChiTietHD = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_KhachHang = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_ChiTietNguyenLieu = new DevExpress.XtraBars.BarButtonItem();
            this.btn_NCC = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_MonAn = new DevExpress.XtraBars.BarButtonItem();
            this.btn_CongDung = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btn_LoaiMonAn = new DevExpress.XtraBars.BarButtonItem();
            this.btn_NguyenLieu = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.Bar_btn_HoSoNhanVien = new DevExpress.XtraBars.BarButtonItem();
            this.btn_QueQuan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barWorkspaceMenuItem1 = new DevExpress.XtraBars.BarWorkspaceMenuItem();
            this.workspaceManager1 = new DevExpress.Utils.WorkspaceManager(this.components);
            this.barMdiChildrenListItem1 = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.btn_DatBan = new DevExpress.XtraBars.BarButtonItem();
            this.btn_chitietdatban = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage9 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.editFormUserControl1 = new DevExpress.XtraGrid.Views.Grid.EditFormUserControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.button1 = new System.Windows.Forms.Button();
            this.ribbonPage7 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbonPage8
            // 
            this.ribbonPage8.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage8.ImageOptions.Image")));
            this.ribbonPage8.Name = "ribbonPage8";
            this.ribbonPage8.Text = "Giới Thiệu";
            // 
            // ribbonPage6
            // 
            this.ribbonPage6.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage6.ImageOptions.Image")));
            this.ribbonPage6.Name = "ribbonPage6";
            this.ribbonPage6.Text = "Thống Kê-Báo Cáo";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup5});
            this.ribbonPage5.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage5.ImageOptions.Image")));
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "Quản Lý Hóa Đơn";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btn_HoaDon);
            this.ribbonPageGroup5.ItemLinks.Add(this.btn_ChiTietHD);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Hóa Đơn";
            // 
            // btn_HoaDon
            // 
            this.btn_HoaDon.Caption = "Hóa Đơn Nhập";
            this.btn_HoaDon.Id = 15;
            this.btn_HoaDon.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_HoaDon.ImageOptions.Image")));
            this.btn_HoaDon.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_HoaDon.ImageOptions.LargeImage")));
            this.btn_HoaDon.Name = "btn_HoaDon";
            this.btn_HoaDon.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_HoaDon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_HoaDon_ItemClick);
            // 
            // btn_ChiTietHD
            // 
            this.btn_ChiTietHD.Caption = "Chi Tiết Hóa Đơn Nhập";
            this.btn_ChiTietHD.Id = 16;
            this.btn_ChiTietHD.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ChiTietHD.ImageOptions.Image")));
            this.btn_ChiTietHD.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_ChiTietHD.ImageOptions.LargeImage")));
            this.btn_ChiTietHD.Name = "btn_ChiTietHD";
            this.btn_ChiTietHD.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_ChiTietHD.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_ChiTietHD_ItemClick);
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4});
            this.ribbonPage4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage4.ImageOptions.Image")));
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Quản Lý Khách Hàng";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.btn_KhachHang);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Thông Tin Khách Hàng";
            // 
            // btn_KhachHang
            // 
            this.btn_KhachHang.Caption = "Thông Tin Khách Hàng";
            this.btn_KhachHang.Id = 14;
            this.btn_KhachHang.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btn_KhachHang.ImageOptions.SvgImage")));
            this.btn_KhachHang.Name = "btn_KhachHang";
            this.btn_KhachHang.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_KhachHang.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_KhachHang_ItemClick);
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage3.ImageOptions.Image")));
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Quản Lý Nguyên Liệu";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.btn_ChiTietNguyenLieu);
            this.ribbonPageGroup3.ItemLinks.Add(this.btn_NCC);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Thông Tin Nguyên Liệu";
            // 
            // btn_ChiTietNguyenLieu
            // 
            this.btn_ChiTietNguyenLieu.Caption = "Chi Tiết Nguyên Liệu";
            this.btn_ChiTietNguyenLieu.Id = 12;
            this.btn_ChiTietNguyenLieu.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_ChiTietNguyenLieu.ImageOptions.Image")));
            this.btn_ChiTietNguyenLieu.Name = "btn_ChiTietNguyenLieu";
            this.btn_ChiTietNguyenLieu.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_ChiTietNguyenLieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_ChiTietNguyenLieu_ItemClick);
            // 
            // btn_NCC
            // 
            this.btn_NCC.Caption = "Nhà Cung Cấp";
            this.btn_NCC.Id = 13;
            this.btn_NCC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_NCC.ImageOptions.Image")));
            this.btn_NCC.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_NCC.ImageOptions.LargeImage")));
            this.btn_NCC.Name = "btn_NCC";
            this.btn_NCC.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_NCC.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_NCC_ItemClick);
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup10});
            this.ribbonPage2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage2.ImageOptions.Image")));
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Quản Lý Món Ăn";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.btn_MonAn);
            this.ribbonPageGroup2.ItemLinks.Add(this.btn_CongDung);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Thông Tin Món Ăn";
            // 
            // btn_MonAn
            // 
            this.btn_MonAn.Caption = "Hồ Sơ Món Ăn";
            this.btn_MonAn.Id = 8;
            this.btn_MonAn.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_MonAn.ImageOptions.Image")));
            this.btn_MonAn.Name = "btn_MonAn";
            this.btn_MonAn.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_MonAn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_MonAn_ItemClick);
            // 
            // btn_CongDung
            // 
            this.btn_CongDung.Caption = "Công Dụng";
            this.btn_CongDung.Id = 9;
            this.btn_CongDung.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_CongDung.ImageOptions.Image")));
            this.btn_CongDung.Name = "btn_CongDung";
            this.btn_CongDung.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_CongDung.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_CongDung_ItemClick);
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.ItemLinks.Add(this.btn_LoaiMonAn);
            this.ribbonPageGroup10.ItemLinks.Add(this.btn_NguyenLieu);
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "Phân Loại";
            // 
            // btn_LoaiMonAn
            // 
            this.btn_LoaiMonAn.Caption = "Loại Món Ăn";
            this.btn_LoaiMonAn.Id = 10;
            this.btn_LoaiMonAn.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_LoaiMonAn.ImageOptions.Image")));
            this.btn_LoaiMonAn.Name = "btn_LoaiMonAn";
            this.btn_LoaiMonAn.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_LoaiMonAn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_LoaiMonAn_ItemClick);
            // 
            // btn_NguyenLieu
            // 
            this.btn_NguyenLieu.Caption = "Nguyên Liệu - Món Ăn";
            this.btn_NguyenLieu.Id = 11;
            this.btn_NguyenLieu.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_NguyenLieu.ImageOptions.Image")));
            this.btn_NguyenLieu.Name = "btn_NguyenLieu";
            this.btn_NguyenLieu.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_NguyenLieu.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_NguyenLieu_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage1.ImageOptions.Image")));
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Quản Lý Nhân Viên";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.Bar_btn_HoSoNhanVien);
            this.ribbonPageGroup1.ItemLinks.Add(this.btn_QueQuan);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Thông Tin Nhân Viên";
            // 
            // Bar_btn_HoSoNhanVien
            // 
            this.Bar_btn_HoSoNhanVien.Caption = "Hồ Sơ Nhân Viên";
            this.Bar_btn_HoSoNhanVien.Id = 6;
            this.Bar_btn_HoSoNhanVien.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("Bar_btn_HoSoNhanVien.ImageOptions.Image")));
            this.Bar_btn_HoSoNhanVien.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("Bar_btn_HoSoNhanVien.ImageOptions.LargeImage")));
            this.Bar_btn_HoSoNhanVien.Name = "Bar_btn_HoSoNhanVien";
            this.Bar_btn_HoSoNhanVien.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.Bar_btn_HoSoNhanVien.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.Bar_btn_HoSoNhanVien_ItemClick_1);
            // 
            // btn_QueQuan
            // 
            this.btn_QueQuan.Caption = "Quê Quán";
            this.btn_QueQuan.Id = 7;
            this.btn_QueQuan.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_QueQuan.ImageOptions.Image")));
            this.btn_QueQuan.Name = "btn_QueQuan";
            this.btn_QueQuan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_QueQuan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_QueQuan_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 1;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Caption = "barButtonGroup1";
            this.barButtonGroup1.Id = 2;
            this.barButtonGroup1.Name = "barButtonGroup1";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Caption = "barButtonGroup2";
            this.barButtonGroup2.Id = 3;
            this.barButtonGroup2.Name = "barButtonGroup2";
            // 
            // barWorkspaceMenuItem1
            // 
            this.barWorkspaceMenuItem1.Caption = "barWorkspaceMenuItem1";
            this.barWorkspaceMenuItem1.Id = 4;
            this.barWorkspaceMenuItem1.Name = "barWorkspaceMenuItem1";
            this.barWorkspaceMenuItem1.WorkspaceManager = this.workspaceManager1;
            // 
            // workspaceManager1
            // 
            this.workspaceManager1.TargetControl = this;
            this.workspaceManager1.TransitionType = pushTransition1;
            // 
            // barMdiChildrenListItem1
            // 
            this.barMdiChildrenListItem1.Caption = "barMdiChildrenListItem1";
            this.barMdiChildrenListItem1.Id = 5;
            this.barMdiChildrenListItem1.Name = "barMdiChildrenListItem1";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonControl1.ApplicationButtonImageOptions.Image")));
            this.ribbonControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.editFormUserControl1.SetBoundPropertyName(this.ribbonControl1, "");
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.barButtonItem1,
            this.barButtonGroup1,
            this.barButtonGroup2,
            this.barWorkspaceMenuItem1,
            this.barMdiChildrenListItem1,
            this.Bar_btn_HoSoNhanVien,
            this.btn_QueQuan,
            this.btn_MonAn,
            this.btn_CongDung,
            this.btn_LoaiMonAn,
            this.btn_NguyenLieu,
            this.btn_ChiTietNguyenLieu,
            this.btn_NCC,
            this.btn_KhachHang,
            this.btn_HoaDon,
            this.btn_ChiTietHD,
            this.btn_DatBan,
            this.btn_chitietdatban});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 19;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4,
            this.ribbonPage5,
            this.ribbonPage9,
            this.ribbonPage6,
            this.ribbonPage8});
            this.ribbonControl1.Size = new System.Drawing.Size(1179, 146);
            // 
            // btn_DatBan
            // 
            this.btn_DatBan.Caption = "Phiếu Đặt Bàn";
            this.btn_DatBan.Id = 17;
            this.btn_DatBan.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_DatBan.ImageOptions.Image")));
            this.btn_DatBan.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_DatBan.ImageOptions.LargeImage")));
            this.btn_DatBan.Name = "btn_DatBan";
            this.btn_DatBan.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_DatBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_DatBan_ItemClick);
            // 
            // btn_chitietdatban
            // 
            this.btn_chitietdatban.Caption = "Chi Tiết Phiếu Đặt Bàn";
            this.btn_chitietdatban.Id = 18;
            this.btn_chitietdatban.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btn_chitietdatban.ImageOptions.Image")));
            this.btn_chitietdatban.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btn_chitietdatban.ImageOptions.LargeImage")));
            this.btn_chitietdatban.Name = "btn_chitietdatban";
            this.btn_chitietdatban.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btn_chitietdatban.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_chitietdatban_ItemClick);
            // 
            // ribbonPage9
            // 
            this.ribbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup6});
            this.ribbonPage9.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage9.ImageOptions.Image")));
            this.ribbonPage9.Name = "ribbonPage9";
            this.ribbonPage9.Text = "Phiếu Đặt Bàn";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.ItemLinks.Add(this.btn_DatBan);
            this.ribbonPageGroup6.ItemLinks.Add(this.btn_chitietdatban);
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "Phiếu Đặt Bàn";
            // 
            // editFormUserControl1
            // 
            this.editFormUserControl1.Location = new System.Drawing.Point(0, 0);
            this.editFormUserControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.editFormUserControl1.Name = "editFormUserControl1";
            this.editFormUserControl1.Size = new System.Drawing.Size(928, 395);
            this.editFormUserControl1.TabIndex = 0;
            // 
            // xtraTabPage1
            // 
            this.editFormUserControl1.SetBoundPropertyName(this.xtraTabPage1, "");
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1173, 448);
            this.xtraTabPage1.Text = "Bắt đầu";
            // 
            // xtraTabControl1
            // 
            this.editFormUserControl1.SetBoundPropertyName(this.xtraTabControl1, "");
            this.xtraTabControl1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InAllTabPageHeaders;
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 146);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(1179, 476);
            this.xtraTabControl1.TabIndex = 6;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1});
            this.xtraTabControl1.CloseButtonClick += new System.EventHandler(this.xtraTabControl1_CloseButtonClick);
            // 
            // button1
            // 
            this.editFormUserControl1.SetBoundPropertyName(this.button1, "");
            this.button1.Location = new System.Drawing.Point(1144, 56);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 19);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // ribbonPage7
            // 
            this.ribbonPage7.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("ribbonPage7.ImageOptions.Image")));
            this.ribbonPage7.Name = "ribbonPage7";
            this.ribbonPage7.Text = "Trợ Giúp";
            // 
            // frm_Main
            // 
            this.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.editFormUserControl1.SetBoundPropertyName(this, "");
            this.ClientSize = new System.Drawing.Size(1179, 622);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Main";
            this.Ribbon = this.ribbonControl1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Bán Hàng";
            this.Load += new System.EventHandler(this.Frm_Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage8;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.BarButtonItem Bar_btn_HoSoNhanVien;
        private DevExpress.XtraBars.BarButtonItem btn_QueQuan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraBars.BarWorkspaceMenuItem barWorkspaceMenuItem1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.BarMdiChildrenListItem barMdiChildrenListItem1;
        private DevExpress.XtraGrid.Views.Grid.EditFormUserControl editFormUserControl1;
        private DevExpress.XtraBars.BarButtonItem btn_MonAn;
        private DevExpress.XtraBars.BarButtonItem btn_CongDung;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage9;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.BarButtonItem btn_LoaiMonAn;
        private DevExpress.XtraBars.BarButtonItem btn_NguyenLieu;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.Utils.WorkspaceManager workspaceManager1;
        private DevExpress.XtraBars.BarButtonItem btn_ChiTietNguyenLieu;
        private DevExpress.XtraBars.BarButtonItem btn_NCC;
        private DevExpress.XtraBars.BarButtonItem btn_KhachHang;
        private DevExpress.XtraBars.BarButtonItem btn_HoaDon;
        private DevExpress.XtraBars.BarButtonItem btn_ChiTietHD;
        private DevExpress.XtraBars.BarButtonItem btn_DatBan;
        private DevExpress.XtraBars.BarButtonItem btn_chitietdatban;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage7;
        private System.Windows.Forms.Button button1;
    }
}

