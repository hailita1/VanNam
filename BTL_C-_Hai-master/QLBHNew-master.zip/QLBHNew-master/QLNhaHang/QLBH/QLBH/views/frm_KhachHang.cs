﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QLBH.Model_Class;
using System.Data.SqlClient;
using QLBH.Repository;
using System.Data.Common;

namespace QLBH
{
    public partial class frm_KhachHang : DevExpress.XtraEditors.XtraForm
    {
        public frm_KhachHang()
        {
            InitializeComponent();
        }
        public new List<Class_Khach> Select()
        {

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {

        }
    }
}