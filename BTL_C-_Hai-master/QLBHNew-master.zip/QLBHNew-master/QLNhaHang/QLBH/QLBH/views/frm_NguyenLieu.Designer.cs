﻿namespace QLBH
{
    partial class frm_NguyenLieu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_NguyenLieu));
            this.button_themmoi = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.txt_ccdtk = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txt_congdungtk = new DevExpress.XtraEditors.TextEdit();
            this.txt_tentk = new DevExpress.XtraEditors.TextEdit();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.button_capnhat = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txt_manl = new DevExpress.XtraEditors.TextEdit();
            this.txt_donvitinh = new DevExpress.XtraEditors.TextEdit();
            this.tablePanel1 = new DevExpress.Utils.Layout.TablePanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.txt_chongchidinh = new DevExpress.XtraEditors.TextEdit();
            this.txt_yeucau = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txt_dongiaban = new DevExpress.XtraEditors.TextEdit();
            this.txt_dongianhap = new DevExpress.XtraEditors.TextEdit();
            this.txt_soluong = new DevExpress.XtraEditors.TextEdit();
            this.txt_congdung = new System.Windows.Forms.TextBox();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txt_tennl = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ccdtk.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_congdungtk.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tentk.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_manl.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_donvitinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablePanel1)).BeginInit();
            this.tablePanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_chongchidinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_yeucau.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dongiaban.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dongianhap.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_soluong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tennl.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // button_themmoi
            // 
            this.button_themmoi.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("button_themmoi.ImageOptions.Image")));
            this.button_themmoi.Location = new System.Drawing.Point(555, 4);
            this.button_themmoi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_themmoi.Name = "button_themmoi";
            this.button_themmoi.Size = new System.Drawing.Size(117, 41);
            this.button_themmoi.TabIndex = 16;
            this.button_themmoi.Text = "Thêm Mới";
            this.button_themmoi.Click += new System.EventHandler(this.Button_themmoi_Click);
            // 
            // panelControl1
            // 
            this.panelControl1.Appearance.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panelControl1.Appearance.Options.UseBackColor = true;
            this.tablePanel1.SetColumn(this.panelControl1, 0);
            this.tablePanel1.SetColumnSpan(this.panelControl1, 2);
            this.panelControl1.Controls.Add(this.txt_ccdtk);
            this.panelControl1.Controls.Add(this.labelControl3);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.txt_congdungtk);
            this.panelControl1.Controls.Add(this.txt_tentk);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(3, 48);
            this.panelControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelControl1.Name = "panelControl1";
            this.tablePanel1.SetRow(this.panelControl1, 1);
            this.panelControl1.Size = new System.Drawing.Size(1560, 34);
            this.panelControl1.TabIndex = 6;
            // 
            // txt_ccdtk
            // 
            this.txt_ccdtk.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_ccdtk.Location = new System.Drawing.Point(908, 6);
            this.txt_ccdtk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_ccdtk.Name = "txt_ccdtk";
            this.txt_ccdtk.Size = new System.Drawing.Size(117, 22);
            this.txt_ccdtk.TabIndex = 6;
            // 
            // labelControl3
            // 
            this.labelControl3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelControl3.Location = new System.Drawing.Point(810, 10);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(101, 17);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "Chống Chỉ Định:";
            // 
            // labelControl2
            // 
            this.labelControl2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelControl2.Location = new System.Drawing.Point(603, 10);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(76, 17);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Công Dụng:";
            // 
            // labelControl1
            // 
            this.labelControl1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelControl1.Location = new System.Drawing.Point(278, 10);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(108, 17);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Tên Nguyên Liệu:";
            // 
            // txt_congdungtk
            // 
            this.txt_congdungtk.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_congdungtk.Location = new System.Drawing.Point(676, 6);
            this.txt_congdungtk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_congdungtk.Name = "txt_congdungtk";
            this.txt_congdungtk.Size = new System.Drawing.Size(117, 22);
            this.txt_congdungtk.TabIndex = 1;
            // 
            // txt_tentk
            // 
            this.txt_tentk.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_tentk.Location = new System.Drawing.Point(383, 6);
            this.txt_tentk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_tentk.Name = "txt_tentk";
            this.txt_tentk.Size = new System.Drawing.Size(182, 22);
            this.txt_tentk.TabIndex = 0;
            // 
            // panelControl2
            // 
            this.tablePanel1.SetColumn(this.panelControl2, 0);
            this.tablePanel1.SetColumnSpan(this.panelControl2, 2);
            this.panelControl2.Controls.Add(this.simpleButton1);
            this.panelControl2.Controls.Add(this.simpleButton4);
            this.panelControl2.Controls.Add(this.button_capnhat);
            this.panelControl2.Controls.Add(this.button_themmoi);
            this.panelControl2.Controls.Add(this.simpleButton5);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(3, 4);
            this.panelControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelControl2.Name = "panelControl2";
            this.tablePanel1.SetRow(this.panelControl2, 0);
            this.panelControl2.Size = new System.Drawing.Size(1560, 36);
            this.panelControl2.TabIndex = 12;
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(926, 4);
            this.simpleButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(117, 41);
            this.simpleButton1.TabIndex = 19;
            this.simpleButton1.Text = "Thoát";
            this.simpleButton1.Click += new System.EventHandler(this.SimpleButton1_Click);
            // 
            // simpleButton4
            // 
            this.simpleButton4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton4.ImageOptions.Image")));
            this.simpleButton4.Location = new System.Drawing.Point(803, 4);
            this.simpleButton4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(117, 41);
            this.simpleButton4.TabIndex = 18;
            this.simpleButton4.Text = "Xóa";
            this.simpleButton4.Click += new System.EventHandler(this.SimpleButton4_Click);
            // 
            // button_capnhat
            // 
            this.button_capnhat.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("button_capnhat.ImageOptions.Image")));
            this.button_capnhat.Location = new System.Drawing.Point(679, 4);
            this.button_capnhat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button_capnhat.Name = "button_capnhat";
            this.button_capnhat.Size = new System.Drawing.Size(117, 41);
            this.button_capnhat.TabIndex = 17;
            this.button_capnhat.Text = "Cập Nhật";
            this.button_capnhat.Click += new System.EventHandler(this.Button_capnhat_Click);
            // 
            // simpleButton5
            // 
            this.simpleButton5.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton5.ImageOptions.Image")));
            this.simpleButton5.Location = new System.Drawing.Point(432, 4);
            this.simpleButton5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(117, 41);
            this.simpleButton5.TabIndex = 15;
            this.simpleButton5.Text = "Tìm Kiếm";
            this.simpleButton5.Click += new System.EventHandler(this.SimpleButton5_Click);
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(398, 135);
            this.labelControl17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(65, 17);
            this.labelControl17.TabIndex = 41;
            this.labelControl17.Text = "Số Lượng:";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(381, 167);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(75, 16);
            this.labelControl10.TabIndex = 34;
            this.labelControl10.Text = "Đơn Giá Bán:";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(36, 167);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(89, 17);
            this.labelControl9.TabIndex = 33;
            this.labelControl9.Text = "Đơn Giá Nhập:";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(50, 135);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(75, 17);
            this.labelControl7.TabIndex = 31;
            this.labelControl7.Text = "Đơn Vị Tính:";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(362, 103);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(102, 17);
            this.labelControl6.TabIndex = 30;
            this.labelControl6.Text = "Mã Nguyên Liệu:";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(17, 103);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(108, 17);
            this.labelControl5.TabIndex = 29;
            this.labelControl5.Text = "Tên Nguyên Liệu:";
            // 
            // txt_manl
            // 
            this.txt_manl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_manl.Location = new System.Drawing.Point(462, 100);
            this.txt_manl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_manl.Name = "txt_manl";
            this.txt_manl.Size = new System.Drawing.Size(204, 22);
            this.txt_manl.TabIndex = 2;
            // 
            // txt_donvitinh
            // 
            this.txt_donvitinh.Location = new System.Drawing.Point(125, 132);
            this.txt_donvitinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_donvitinh.Name = "txt_donvitinh";
            this.txt_donvitinh.Size = new System.Drawing.Size(223, 22);
            this.txt_donvitinh.TabIndex = 1;
            // 
            // tablePanel1
            // 
            this.tablePanel1.Columns.AddRange(new DevExpress.Utils.Layout.TablePanelColumn[] {
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 32.61F),
            new DevExpress.Utils.Layout.TablePanelColumn(DevExpress.Utils.Layout.TablePanelEntityStyle.Relative, 27.39F)});
            this.tablePanel1.Controls.Add(this.dataGridView1);
            this.tablePanel1.Controls.Add(this.groupControl1);
            this.tablePanel1.Controls.Add(this.panelControl1);
            this.tablePanel1.Controls.Add(this.panelControl2);
            this.tablePanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tablePanel1.Location = new System.Drawing.Point(0, 0);
            this.tablePanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tablePanel1.Name = "tablePanel1";
            this.tablePanel1.Rows.AddRange(new DevExpress.Utils.Layout.TablePanelRow[] {
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 44F),
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 42F),
            new DevExpress.Utils.Layout.TablePanelRow(DevExpress.Utils.Layout.TablePanelEntityStyle.Absolute, 26F)});
            this.tablePanel1.Size = new System.Drawing.Size(1566, 652);
            this.tablePanel1.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.tablePanel1.SetColumn(this.dataGridView1, 0);
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 90);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.tablePanel1.SetRow(this.dataGridView1, 2);
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(845, 558);
            this.dataGridView1.TabIndex = 17;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.DataGridView1_DoubleClick);
            // 
            // groupControl1
            // 
            this.tablePanel1.SetColumn(this.groupControl1, 1);
            this.groupControl1.Controls.Add(this.txt_chongchidinh);
            this.groupControl1.Controls.Add(this.txt_yeucau);
            this.groupControl1.Controls.Add(this.labelControl4);
            this.groupControl1.Controls.Add(this.labelControl11);
            this.groupControl1.Controls.Add(this.txt_dongiaban);
            this.groupControl1.Controls.Add(this.txt_dongianhap);
            this.groupControl1.Controls.Add(this.txt_soluong);
            this.groupControl1.Controls.Add(this.txt_congdung);
            this.groupControl1.Controls.Add(this.labelControl8);
            this.groupControl1.Controls.Add(this.labelControl17);
            this.groupControl1.Controls.Add(this.labelControl10);
            this.groupControl1.Controls.Add(this.labelControl9);
            this.groupControl1.Controls.Add(this.labelControl7);
            this.groupControl1.Controls.Add(this.labelControl6);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.txt_manl);
            this.groupControl1.Controls.Add(this.txt_donvitinh);
            this.groupControl1.Controls.Add(this.txt_tennl);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl1.GroupStyle = DevExpress.Utils.GroupStyle.Light;
            this.groupControl1.Location = new System.Drawing.Point(854, 90);
            this.groupControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupControl1.Name = "groupControl1";
            this.tablePanel1.SetRow(this.groupControl1, 2);
            this.groupControl1.Size = new System.Drawing.Size(709, 558);
            this.groupControl1.TabIndex = 16;
            this.groupControl1.Text = "Chi Tiết Thân Nhân";
            // 
            // txt_chongchidinh
            // 
            this.txt_chongchidinh.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_chongchidinh.Location = new System.Drawing.Point(462, 196);
            this.txt_chongchidinh.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_chongchidinh.Name = "txt_chongchidinh";
            this.txt_chongchidinh.Size = new System.Drawing.Size(204, 22);
            this.txt_chongchidinh.TabIndex = 51;
            // 
            // txt_yeucau
            // 
            this.txt_yeucau.Location = new System.Drawing.Point(125, 196);
            this.txt_yeucau.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_yeucau.Name = "txt_yeucau";
            this.txt_yeucau.Size = new System.Drawing.Size(223, 22);
            this.txt_yeucau.TabIndex = 50;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(364, 199);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(101, 17);
            this.labelControl4.TabIndex = 49;
            this.labelControl4.Text = "Chống Chỉ Định:";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(36, 199);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(56, 17);
            this.labelControl11.TabIndex = 48;
            this.labelControl11.Text = "Yêu Cầu:";
            // 
            // txt_dongiaban
            // 
            this.txt_dongiaban.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_dongiaban.Location = new System.Drawing.Point(462, 164);
            this.txt_dongiaban.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_dongiaban.Name = "txt_dongiaban";
            this.txt_dongiaban.Size = new System.Drawing.Size(204, 22);
            this.txt_dongiaban.TabIndex = 47;
            this.txt_dongiaban.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_dongiaban_KeyPress);
            // 
            // txt_dongianhap
            // 
            this.txt_dongianhap.Location = new System.Drawing.Point(125, 164);
            this.txt_dongianhap.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_dongianhap.Name = "txt_dongianhap";
            this.txt_dongianhap.Size = new System.Drawing.Size(223, 22);
            this.txt_dongianhap.TabIndex = 46;
            this.txt_dongianhap.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_dongianhap_KeyPress);
            // 
            // txt_soluong
            // 
            this.txt_soluong.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_soluong.Location = new System.Drawing.Point(462, 132);
            this.txt_soluong.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_soluong.Name = "txt_soluong";
            this.txt_soluong.Size = new System.Drawing.Size(204, 22);
            this.txt_soluong.TabIndex = 45;
            this.txt_soluong.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Txt_soluong_KeyPress);
            // 
            // txt_congdung
            // 
            this.txt_congdung.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_congdung.Location = new System.Drawing.Point(125, 231);
            this.txt_congdung.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_congdung.Multiline = true;
            this.txt_congdung.Name = "txt_congdung";
            this.txt_congdung.Size = new System.Drawing.Size(541, 109);
            this.txt_congdung.TabIndex = 44;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(36, 281);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(71, 17);
            this.labelControl8.TabIndex = 43;
            this.labelControl8.Text = "Công Dụng";
            // 
            // txt_tennl
            // 
            this.txt_tennl.Location = new System.Drawing.Point(125, 100);
            this.txt_tennl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txt_tennl.Name = "txt_tennl";
            this.txt_tennl.Size = new System.Drawing.Size(223, 22);
            this.txt_tennl.TabIndex = 0;
            // 
            // frm_NguyenLieu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1566, 652);
            this.ControlBox = false;
            this.Controls.Add(this.tablePanel1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frm_NguyenLieu";
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.Frm_NguyenLieu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_ccdtk.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_congdungtk.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tentk.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_manl.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_donvitinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablePanel1)).EndInit();
            this.tablePanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_chongchidinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_yeucau.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dongiaban.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_dongianhap.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_soluong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_tennl.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton button_themmoi;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.Utils.Layout.TablePanel tablePanel1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit txt_chongchidinh;
        private DevExpress.XtraEditors.TextEdit txt_yeucau;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txt_dongiaban;
        private DevExpress.XtraEditors.TextEdit txt_dongianhap;
        private DevExpress.XtraEditors.TextEdit txt_soluong;
        private System.Windows.Forms.TextBox txt_congdung;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txt_manl;
        private DevExpress.XtraEditors.TextEdit txt_donvitinh;
        private DevExpress.XtraEditors.TextEdit txt_tennl;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton button_capnhat;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private DevExpress.XtraEditors.TextEdit txt_ccdtk;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txt_congdungtk;
        private DevExpress.XtraEditors.TextEdit txt_tentk;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}